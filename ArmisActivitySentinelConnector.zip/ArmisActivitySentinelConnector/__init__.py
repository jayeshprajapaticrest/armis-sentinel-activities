"""This __init__ file will be called once triggered is generated."""
import datetime
import logging
import azure.functions as func
import base64
import hashlib
import hmac
import json
import os
import requests
from .state_manager import StateManager
from Exceptions.ArmisExceptions import ArmisException

API_KEY = os.environ["ArmisSecretKey"]
url = os.environ["ArmisURL"]
connection_string = os.environ["AzureWebJobsStorage"]
customer_id = os.environ["WorkspaceID"]
shared_key = os.environ["WorkspaceKey"]
armis_activities = os.environ["ArmisActivitiesTableName"]

HTTP_ERRORS = {
    400: "Armis Activity Connecter: Bad request: Missing aql Parameter.",
    401: "Armis Activity Connecter: Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Armis Activity Connecter: Access Token not found. Please check Key.",
    "HOST_CONNECTION_ERROR": "Armis Activity Connecter: Invalid host while verifying 'Armis Account'.",
}
data_activity_from, retry_activity_token = 0, 1

body = ""


class ArmisActivity:
    """This class will process the Activity data and post it into the Azure sentinel."""

    def __init__(self):
        """This method will initialize object of class."""
        self._link = url
        self._header = {
            "Content-Type": "application/json",
        }
        self._secret_key = API_KEY

    def _get_access_token_activity(self, armis_link_suffix):
        """
        This method will fetch the access token using api and.
        set it in header for further use.

        Args:
            armis_link_suffix (String): This variable will be suffix/add-on to the link.

        """
        if self._secret_key is not None and self._link is not None:
            parameter = {"secret_key": self._secret_key}
            try:
                response = requests.post(
                    (self._link + armis_link_suffix), params=parameter
                )
                if response.status_code == 200:
                    logging.info("Armis Activity Connecter: Getting Access Token.")
                    _access_token = json.loads(response.text)["data"]["access_token"]
                    self._header.update({"Authorization": _access_token})
                elif response.status_code == 400:
                    raise ArmisException(
                        "Armis Activity Connecter: Bad request, please check the arguments you passed."
                    )

                else:
                    raise ArmisException(
                        "Armis Activity Connecter: Error while generating the access token. Error code: {}.".format(
                            response.status_code
                        )
                    )

            except ArmisException as err:
                logging.error(err)
                raise ArmisException(
                    "Armis Activity Connecter: Error while generating the access token."
                )

        else:
            raise ArmisException(
                "Armis Activity Connecter: The secret key or link has not been initialized."
            )

    def _get_activity_data(self, armis_link_suffix, parameter):
        """_get_activity_data is used to get data using api.

        Args:
            self: Armis object.
            armis_link_suffix (String): will be containing the other part of link.
            parameter (json): will contain the json data to sends to parameter to get data from REST API.

        """
        try:
            global data_activity_from, retry_activity_token

            response = requests.get(
                (self._link + armis_link_suffix), params=parameter, headers=self._header
            )
            if response.status_code == 200:
                logging.info(
                    "Armis Activity Connecter: Getting data with response code %s",
                    response.status_code,
                )
                results = json.loads(response.text)
                if (
                    "data" in results
                    and "results" in results["data"]
                    and "total" in results["data"]
                    and "count" in results["data"]
                    and "next" in results["data"]
                ):
                    total_data_length = results["data"]["total"]
                    count_per_frame_data = results["data"]["count"]
                    data = results["data"]["results"]

                    body = json.dumps(data, indent=2)
                    logging.info(
                        "Armis Activity Connecter: From this length %s we are fetching data.",
                        data_activity_from,
                    )
                    data_activity_from = results["data"]["next"]
                    logging.info(
                        "Armis Activity Connecter: Next page will be from %s",
                        data_activity_from,
                    )
                    current_time = data[-1]["time"][:-13]

                    return body, current_time, total_data_length, count_per_frame_data
                else:
                    raise ArmisException(
                        "Armis Activity Connecter: There are no proper keys in data."
                    )

            elif response.status_code == 400:
                raise ArmisException(HTTP_ERRORS[400])

            elif response.status_code == 401 and retry_activity_token <= 3:
                logging.info(
                    "Armis Activity Connecter: Retry number: {}".format(
                        str(retry_activity_token)
                    )
                )
                retry_activity_token += 1
                logging.error(HTTP_ERRORS[401])
                logging.info("Armis Activity Connecter: Generating Access Token Again!")
                self._get_access_token_activity("/access_token/")
                return self._get_activity_data(armis_link_suffix, parameter)
            else:
                raise ArmisException(
                    "Armis Activity Connecter: Error while fetching data. Status Code:{} Error Message:{}.".format(
                        response.status_code, response.text
                    )
                )

        except requests.exceptions.ConnectionError:
            logging.error(ERROR_MESSAGES["HOST_CONNECTION_ERROR"])
            raise ArmisException(
                "Armis Activity Connecter:Connection error while getting data from activity api."
            )

        except requests.exceptions.RequestException as request_err:
            logging.error(request_err)
            raise ArmisException(
                "Armis Activity Connecter:Request error while getting data from activity api."
            )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Activity Connecter: Error while getting data from activity api."
            )

    def _fetch_activity_data(
        self, type_data, state, table_name, is_table_not_exist, last_time=None
    ):
        """Fetch_activity_data is used to push all the data into table.

        Args:
            self: Armis object.
            type_data (json): will contain the json data to use in the _get_links function.
            state (object): StateManager object.
            table_name (String): table name to store the data in azure sentinel.
            is_table_not_exist (bool): it is a flag that contains the value if table exists or not.
            last_time (String): it will contain latest time stamp.
        """
        try:
            self._get_access_token_activity("/access_token/")
            if is_table_not_exist:
                aql_data = """{} """.format(type_data["aql"])
            else:
                aql_data = """{} after:{} """.format(type_data["aql"], last_time)
            type_data["aql"] = aql_data
            logging.info(
                "Armis Activity Connecter: aql data new " + str(type_data["aql"])
            )

            azuresentinel = AzureSentinel()
            while data_activity_from is not None:
                parameter_activity = {
                    "aql": type_data["aql"],
                    "from": data_activity_from,
                    "orderBy": "time",
                    "length": 1000,
                    "fields": type_data["fields"],
                }
                (
                    body,
                    current_time,
                    total_data_length,
                    count_per_frame_data,
                ) = self._get_activity_data("/search/", parameter_activity)
                logging.info(
                    "Armis Activity Connecter: Total length of data is %s ",
                    total_data_length,
                )
                logging.info("Armis Activity Connecter: Data Gathered SuccessFully.")
                azuresentinel.post_data(customer_id, body, table_name)
                logging.info(
                    "Armis Activity Connecter: Collected %s data of %s into sentinel.",
                    count_per_frame_data,
                    type_data["aql"],
                )
                state.post(str(current_time))
                logging.info(
                    "Armis Activity Connecter: Time stamp added at: "
                    + str(current_time)
                )
                logging.info(
                    "Armis Activity Connecter: StateManager Time_Data Posted Successfully!"
                )
        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Activity Connecter: Error while processing the data."
            )

    def check_data_exists_or_not_activity(self):
        """Check_data_exists_or_not is to check if the data is exists or not using the timestamp file.

        Args:
            self: Armis object.
        """
        try:
            parameter_activity = {
                "aql": "in:activity",
                "orderBy": "time",
                "fields": "title,type,time,site,sensor,protocol,content,activityUUID",
            }
            state_activities = StateManager(
                connection_string=connection_string, file_path="funcarmisactivitiesfile"
            )
            last_time_activities = state_activities.get()
            if last_time_activities is None:
                logging.info(
                    "Armis Activity Connecter: The last time point is not available in activities!"
                )
                self._fetch_activity_data(
                    parameter_activity,
                    state_activities,
                    armis_activities,
                    True,
                    last_time_activities,
                )
                logging.info(
                    "Armis Activity Connecter: Data added when no logs was there."
                )
            else:
                logging.info(
                    "Armis Activity Connecter: The last time point is available in activities: {}.".format(
                        last_time_activities
                    )
                )
                self._fetch_activity_data(
                    parameter_activity,
                    state_activities,
                    armis_activities,
                    False,
                    last_time_activities,
                )
                logging.info(
                    "Armis Activity Connecter: Data added when logs was already in %s.",
                    armis_activities,
                )
            logging.info("Armis Activity Connecter: Activity data added successfully !")
        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Activity Connecter: Error occured during checking whether log table exist or not."
            )


class AzureSentinel:
    """AzureSentinel is Used to post data to log analytics."""

    def build_signature(
        self,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        """To build the signature."""
        x_headers = "x-ms-date:" + date
        string_to_hash = (
            method
            + "\n"
            + str(content_length)
            + "\n"
            + content_type
            + "\n"
            + x_headers
            + "\n"
            + resource
        )
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
        return authorization

    # Build and send a request to the POST API
    def post_data(self, customer_id, body, log_type):
        """Build and send a request to the POST API."""
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        try:
            signature = self.build_signature(
                rfc1123date,
                content_length,
                method,
                content_type,
                resource,
            )
        except ArmisException as err:
            logging.error("Armis Activity Connecter: Error occured: {}".format(err))
            raise ArmisException(
                "Armis Activity Connecter: Error while generating signature for log analytics."
            )

        uri = (
            "https://"
            + customer_id
            + ".ods.opinsights.azure.com"
            + resource
            + "?api-version=2016-04-01"
        )

        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": log_type,
            "x-ms-date": rfc1123date,
        }
        try:
            response = requests.post(uri, data=body, headers=headers)
            if response.status_code >= 200 and response.status_code <= 299:
                logging.info(
                    "Armis Activity Connecter: Data Posted Successfully to azure setninel."
                )
            else:
                raise ArmisException(
                    "Armis Activity Connecter: Response code: {} from posting data to log analytics.".format(
                        response.status_code
                    )
                )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Activity Connecter: Error while posting data to azure sentinel."
            )


def main(mytimer: func.TimerRequest) -> None:
    """This main function will be triggered on specific interval."""
    try:
        utc_timestamp = (
            datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        )
        logging.info(
            "Armis Activity Connecter: Python timer trigger function ran at %s",
            utc_timestamp,
        )

        armis_obj = ArmisActivity()
        armis_obj.check_data_exists_or_not_activity()
        utc_timestamp_final = (
            datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        )
        logging.info(
            "Armis Activity Connecter: Execution Completed for Activity at %s.",
            utc_timestamp_final,
        )
        if mytimer.past_due:
            logging.info("Armis Activity Connecter: The timer is past due!")
    except ArmisException as err:
        logging.error(err)
